<?php
	session_start();
	session_destroy();
?>
<html>
	<head>
	<meta HTTP-EQUIV="REFRESH" content="0; url=index.php" />	
	</head>
	<body>
	</body>
</html>
