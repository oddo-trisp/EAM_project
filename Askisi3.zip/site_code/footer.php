<div id="footer">
    <center>
        <div class="logos">
            <a href="http://www.uoa.gr" target="_blank"><img src="assets/img/nkualogo.gif"></a>
            <a href="http://www.epeaek.gr/epeaek/el/index.html" target="_blank"><img src="assets/img/epeaeklogo.gif"></a>
        </div>
        <div class="social">
            <img src="assets/img/social/facebook.png" title="facebook"/>
            <img src="assets/img/social/twitter.png" title="twitter"/>
            <img src="assets/img/social/linkedin.png" title="linkedin"/>
            <img src="assets/img/social/googleplus.png" title="google+"/>
            <img src="assets/img/social/rss.png" title="rss"/>
            <img src="assets/img/social/email-blue.png" title="email"/>
            <br />
            <a href="contact.php">Επικοινωνία</a> |
            <a href="#">Σχετικά με τον ιστότοπο</a> |
            <a href="#">Πολιτική Απορρήτου</a>
        </div>
        <div class="copy">
            <p>
                &copy 2015. All rights reserved.
            </p>
        </div>
    </center>
</div>
